<?php
    $username = trim(filter_var($_POST['username'], FILTER_SANITIZE_STRING));
    $email = trim(filter_var($_POST['email'], FILTER_SANITIZE_EMAIL));
    $login = trim(filter_var($_POST['login'], FILTER_SANITIZE_STRING));
    $password = trim(filter_var($_POST['password'], FILTER_SANITIZE_STRING));

    $error = '';

    if(strlen($username) <= 3)
    $error = 'Please enter name';
    elseif (strlen($email) <= 3)
    $error = 'Please enter email';
    else if (strlen($login) <= 3)
    $error = 'Please enter login';
    else if (strlen($password) <= 3)
    $error = 'Please enter password';

    if($error != '') {
        echo $error;
        exit();
    }


    $hash = 'gygyhfjfjfjfjfuy55j55j5hguhcjhdfdgfydfhr7';
    $password = md5($password . $hash);

    require_once $_SERVER['DOCUMENT_ROOT'] .'/includes/config.php';

    $sql = 'INSERT INTO users(username, email, login, password) VALUES(?, ?, ?, ?)';
    $query = $pdo->prepare($sql);
    $query->execute([$username, $email, $login, $password]);

    echo 'OK';

?>