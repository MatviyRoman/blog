    <footer class="footer">
        <div class="container">
            <div class="copyright">
                <a href="/" class="site_title"><?=$_SERVER['HTTP_HOST']?></a> - 2020 copyright reserved
            </div>
        </div>
    </footer>
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->
    <script src="/js/jquery.min.js"></script>
    <script src="/js/main.min.js"></script>
    </body>

    </html>