<div class="aside block">Second part of site
    <div class="text">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis sapiente ducimus ipsum qui animi
        earum voluptates. Optio, id magni! Eum iusto quibusdam perferendis ducimus praesentium cumque facere
        dolor explicabo exercitationem!
    </div>
    <div class="picture">
        <img src="/img/MAMP-PRO-Logo.png" alt="">
    </div>
</div>